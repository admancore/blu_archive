<?php

namespace App\Filament\Resources\KategorisResource\Pages;

use App\Filament\Resources\KategorisResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKategoris extends CreateRecord
{
    protected static string $resource = KategorisResource::class;
}
