<?php

namespace App\Filament\Resources\ProvincesResource\Pages;

use App\Filament\Resources\ProvincesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProvinces extends CreateRecord
{
    protected static string $resource = ProvincesResource::class;
}
